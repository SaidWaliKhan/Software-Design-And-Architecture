/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import dataaccess.NoteDAOInterface;
import model.Note;

import java.util.List;

public class NoteService implements NoteServiceInterface {
    private NoteDAOInterface noteDAO;

    public NoteService(NoteDAOInterface noteDAO) {
        this.noteDAO = noteDAO; // Dependency Injection
    }

    @Override
    public void addNote(String title, String content) {
        Note note = new Note(title, content);
        noteDAO.save(note);
    }

    @Override
    public List<Note> getAllNotes() {
        return noteDAO.getAllNotes();
    }
}

