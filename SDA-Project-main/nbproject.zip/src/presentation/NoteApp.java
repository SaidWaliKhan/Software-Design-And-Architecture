package presentation;

import model.Note;
import service.NoteService;
import service.NoteServiceInterface;
import dataaccess.NoteDAO;
import dataaccess.NoteDAOInterface;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class NoteApp extends JFrame {
    private NoteServiceInterface noteService;

    // GUI Components
    private JTextField titleField;
    private JTextArea contentArea;
    private DefaultListModel<String> notesListModel;
    private JList<String> notesList;
    private JTextArea detailArea;

    public NoteApp() {
        // Initialize DAO and Service
        NoteDAOInterface noteDAO = new NoteDAO();
        noteService = new NoteService(noteDAO);

        setTitle("Enhanced Note-Keeping App");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setResizable(true);

        // Create main panel with padding
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        add(mainPanel);

        // Input Panel for adding new notes
        JPanel inputPanel = createInputPanel();
        mainPanel.add(inputPanel, BorderLayout.NORTH);

        // Split pane for note list and detail view
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, createNotesListPanel(), createDetailPanel());
        splitPane.setDividerLocation(250);
        mainPanel.add(splitPane, BorderLayout.CENTER);

        updateNotesList();
    }

    private JPanel createInputPanel() {
        JPanel inputPanel = new JPanel(new BorderLayout(5, 5));

        // Title input
        titleField = new JTextField();
        titleField.setBorder(BorderFactory.createTitledBorder("Title"));
        inputPanel.add(titleField, BorderLayout.NORTH);

        // Content input area
        contentArea = new JTextArea(4, 20);
        contentArea.setBorder(BorderFactory.createTitledBorder("Content"));
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        inputPanel.add(new JScrollPane(contentArea), BorderLayout.CENTER);

        // Button to add note
        JButton addNoteButton = new JButton("Add Note");
        addNoteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNote();
            }
        });
        inputPanel.add(addNoteButton, BorderLayout.SOUTH);

        return inputPanel;
    }

    private JPanel createNotesListPanel() {
        JPanel listPanel = new JPanel(new BorderLayout());
        listPanel.setBorder(BorderFactory.createTitledBorder("Your Notes"));

        notesListModel = new DefaultListModel<>();
        notesList = new JList<>(notesListModel);
        notesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        notesList.addListSelectionListener(e -> showNoteDetails());

        JScrollPane listScrollPane = new JScrollPane(notesList);
        listScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        listPanel.add(listScrollPane, BorderLayout.CENTER);

        return listPanel;
    }

    private JPanel createDetailPanel() {
        JPanel detailPanel = new JPanel(new BorderLayout());
        detailPanel.setBorder(BorderFactory.createTitledBorder("Note Details"));

        // Detail view area
        detailArea = new JTextArea();
        detailArea.setEditable(false);
        detailArea.setLineWrap(true);
        detailArea.setWrapStyleWord(true);

        JScrollPane detailScrollPane = new JScrollPane(detailArea);
        detailScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        detailPanel.add(detailScrollPane, BorderLayout.CENTER);

        return detailPanel;
    }

    private void addNote() {
        // Retrieve text from input fields
        String title = titleField.getText();
        String content = contentArea.getText();

        // Check if title and content are not empty
        if (title.isEmpty() || content.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in both title and content.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Use service layer to add the note
        noteService.addNote(title, content);

        // Clear input fields and update note list
        titleField.setText("");
        contentArea.setText("");
        updateNotesList();

        JOptionPane.showMessageDialog(this, "Note added successfully!");
    }

    private void updateNotesList() {
        notesListModel.clear();
        List<Note> notes = noteService.getAllNotes();
        for (Note note : notes) {
            notesListModel.addElement(note.getTitle());
        }
    }

    private void showNoteDetails() {
        int selectedIndex = notesList.getSelectedIndex();
        if (selectedIndex != -1) {
            Note selectedNote = noteService.getAllNotes().get(selectedIndex);
            detailArea.setText(selectedNote.toString());
        } else {
            detailArea.setText("");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            NoteApp app = new NoteApp();
            app.setVisible(true);
        });
    }
}
