/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataaccess;

import model.Note;
import java.util.List;

public interface NoteDAOInterface {
    void save(Note note);
    List<Note> getAllNotes();

    public List<Note> loadAllNotes();
}

