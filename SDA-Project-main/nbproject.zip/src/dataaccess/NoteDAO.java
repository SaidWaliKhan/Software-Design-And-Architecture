/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataaccess;

import model.Note;

import java.util.ArrayList;
import java.util.List;

public class NoteDAO implements NoteDAOInterface {
    private List<Note> notes = new ArrayList<>();

    @Override
    public void save(Note note) {
        notes.add(note);
        System.out.println("Note saved successfully!");
    }

    @Override
    public List<Note> getAllNotes() {
        return notes;
    }

    @Override
    public List<Note> loadAllNotes()
    {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

