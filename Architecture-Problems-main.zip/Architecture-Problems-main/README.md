# Architecture-Problems

I have implemented the example in JavaScript in a manner that is both easy to understand.
