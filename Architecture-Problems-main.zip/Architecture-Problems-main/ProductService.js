class ProductService {
    getProducts() {
      return ['Product1', 'Product2', 'Product3'];
    }
  }
  